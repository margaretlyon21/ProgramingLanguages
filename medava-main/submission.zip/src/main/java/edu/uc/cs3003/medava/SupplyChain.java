package edu.uc.cs3003.medava;

public class SupplyChain {
    public static void main(String args[]) {
        //run the transport
        HospitalRunner.run();
    }
}
